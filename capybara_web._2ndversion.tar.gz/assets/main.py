import pygame
import asyncio
import random
from pygame import mixer

#sets the audio settings,font path and screen dimension
pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.init()
pixel_font = 'fonts/Pixel_game.otf'
screen = pygame.display.set_mode((800, 600))

def load_image(path, size):
    img = pygame.image.load(path).convert_alpha()
    return pygame.transform.scale(img, size)
#Class for sprites
class FallingSprite:
    def __init__(self, image, gravity=0.05):
        self.image = image
        self.gravity = gravity
        self.rect = image.get_rect()
        self.velocity = 2.0
        self.reset()

    def reset(self):
        self.rect.x = random.randint(50,750)
        self.rect.y = random.randint(0,10)
        self.y = float(self.rect.y)
        self.velocity = 2.0

    def update(self):
        self.velocity += self.gravity
        self.y += self.velocity
        self.rect.y = int(self.y)
        if self.rect.y > 470:
            self.reset()

    def draw(self,screen):
        screen.blit(self.image,self.rect)

class Capybara:
    def __init__(self,image):
        self.image = image
        self.rect = image.get_rect()
        self.reset()

    def reset(self):
        self.rect.x = 250
        self.rect.y = 450

    def move(self):
        keys = pygame.key.get_pressed()
        move_left = keys[pygame.K_LEFT]
        move_right = keys[pygame.K_RIGHT]
        # Touch / mouse: hold the left half to go left, the right half to go right
        if pygame.mouse.get_pressed()[0]:
            if pygame.mouse.get_pos()[0] < 400:
                move_left = True
            else:
                move_right = True
        if move_left:
            self.rect.x -= 6
        if move_right:
            self.rect.x += 6
        # Keep capybara inside the screen
        if self.rect.x < 0:
            self.rect.x = 0
        if self.rect.x > 700:
            self.rect.x = 700

    def draw(self,screen):
        screen.blit(self.image,self.rect)

#Game assets
watermelon_img = load_image('images/watermelon.png',(60,60))
watermelons = [FallingSprite(watermelon_img) for i in range(2)] #2 watermelons

bomb_img = load_image('images/bomb.png',(50,60))
bombs = [FallingSprite(bomb_img) for b in range(2)]

superpower_img = load_image('images/superpower.png',(55,50))
superpowers = [FallingSprite(superpower_img) for s in range(1)] #1 superpower

crocodile_img = load_image('images/crocodile.png',(70,70))
crocodiles = [FallingSprite(crocodile_img) for c in range(2)] #2 crocodiles

capybara_image = load_image('images/capybara.png',(100,95))
capybara = Capybara(capybara_image)

async def main():

    game_state = "intro"
    scores = 0
    life = 5
    level = 1

    #set up the screen of the game
    pygame.display.set_caption("Capybara Catching Game")
    icon = pygame.image.load('images/capybara.png')
    pygame.display.set_icon(icon)

    #fonts
    title_font = pygame.font.Font(pixel_font, 36)
    subtitle_font = pygame.font.Font(pixel_font, 25)
    level_font = pygame.font.Font(pixel_font, 20)
    score_font = pygame.font.Font(pixel_font, 30)
    heart_font = pygame.font.Font(pixel_font, 30)
    win_font = pygame.font.Font(pixel_font, 50)
    game_over_font = pygame.font.Font(pixel_font, 50)

    # load background at the start of the game and store them to use later
    def load_bg(file_name):
        img = pygame.image.load(file_name).convert()
        return pygame.transform.scale(img, (800, 600))

    bg_images = {
        1: load_bg('images/level1_bg.png'),
        2: load_bg('images/level2_bg.png'),
        3: load_bg('images/level3_bg.png'),
    }

    # instruction text to show before game start
    title_text = title_font.render("CAPYBARA CATCHING WATERMELON", True, (255, 210, 63))
    game_rule = subtitle_font.render('''
    HOW TO PLAY 
        You have 5 Lives 
        CATCH 1 WATERMELON -> GET 1 POINT 
        TOUCH A BOMB -> LOSE 1 LIFE
        SCORE 10 POINTS -> GO TO LEVEL 2
        SCORE 20 POINTS -> GO TO LEVEL 3
    IN LEVEL 3:
        TOUCH A SUPERPOWER -> GAIN 1 LIFE
        TOUCH A CROCODILE -> LOSE 2 LIVES
    PRESS SPACE OR TAP TO START LEVEL 1 ''',True, (255, 255, 255))

    win_text = win_font.render("YOU WIN!", True, (255, 255, 255))
    game_over_text = game_over_font.render("GAME OVER!", True, (255, 0, 0))
    restart_text = subtitle_font.render("Press R or TAP to play again", True, (255, 255, 255))
    restart_rect = restart_text.get_rect(center=(380, 320))

    # score and heart icons
    score_img = pygame.image.load('images/score.png').convert_alpha()
    score_icon = pygame.transform.scale(score_img, (50, 50))
    heart_img = pygame.image.load('images/heart.png').convert_alpha()
    heart_icon = pygame.transform.scale(heart_img, (40, 40))

    # for background music , use mixer.music and do loop -1 -> so it plays forever until game finished
    mixer.music.load('sound/capy_bgmusic.ogg')
    #use mixer.sound for sound effects
    eat_sound = mixer.Sound('sound/eating.ogg')
    level2_sound = mixer.Sound('sound/Level2_bg.ogg')
    level3_sound = mixer.Sound('sound/Level3_bg.ogg')
    game_over = mixer.Sound('sound/game_over.ogg')
    win_sound = mixer.Sound('sound/win.ogg')
    win_sound_played = False
    game_over_sound_played = False

#Game functions
    panel = pygame.Surface((650, 350), pygame.SRCALPHA)
    panel.fill((0, 0, 0, 170))
    def show_intro():
        screen.blit(panel, (75, 115))
        screen.blit(title_text, (180, 70))
        screen.blit(game_rule,(200,110))

    def show_win():
        screen.blit(bg_images[3], (0, 0))
        screen.blit(win_text, (300, 250))
        screen.blit(restart_text, restart_rect)

    def show_game_over():
        screen.blit(bg_images[3], (0, 0))
        screen.blit(game_over_text, (300, 250))
        screen.blit(restart_text, restart_rect)

    def show_score():
        screen.blit(score_font.render(str(scores), True, (255, 0, 0)), (90, 20))
        screen.blit(score_icon, (20, 10))

    def show_heart():
        screen.blit(heart_font.render(str(life), True, (255, 0, 0)), (90, 65))
        screen.blit(heart_icon, (25, 60))

    def show_level():
        level_text = level_font.render("Level: " + str(level), True, (0, 255, 0))
        screen.blit(level_text, (680, 10))

    def play_background_music():
        mixer.music.stop()
        mixer.music.play(-1)

    def increase_level(new_level,gravity,sound):
        nonlocal level
        level = new_level
        bombs.append(FallingSprite(bomb_img,gravity))
        for obj in bombs + watermelons:
            obj.gravity = gravity
        sound.play()

    #Collision Detection
    def object_falling(objects,other_obj):
        collided = False
        for object in objects:
            object.update()
            object.draw(screen)
            if object.rect.colliderect(other_obj.rect):
                object.reset()
                collided = True
        return collided

    def reset_game():
        nonlocal game_state, scores, life, level
        nonlocal win_sound_played, game_over_sound_played
        scores = 0
        life = 5
        level = 1
        win_sound_played = False
        game_over_sound_played = False
        capybara.reset()
        bombs[:] = bombs[:2]
        for obj in watermelons+bombs+superpowers+crocodiles:
            obj.reset()
        play_background_music()
        game_state = "playing"

    clock = pygame.time.Clock()
    running = True
    play_background_music()
    #main game loop
    while running:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            #for keyboard
            if event.type == pygame.KEYDOWN:
                if game_state == "intro":
                    if event.key == pygame.K_SPACE:
                        game_state = "playing"
                elif game_state in ("win", "game_over"):
                    if event.key in [pygame.K_r]:
                        reset_game()
            #for touch screen using tap
            elif event.type in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN):
                if game_state == "intro":
                    game_state = "playing"
                elif game_state in ("win", "game_over"):
                    reset_game()

        # intro screen
        if game_state == "intro":
            screen.blit(bg_images[1], (0, 0))
            show_intro()

        # playing screen
        elif game_state == "playing":
            screen.blit(bg_images[level], (0, 0))
            show_score()
            show_heart()
            show_level()
            capybara.draw(screen)
            capybara.move()

            if object_falling(watermelons,capybara):
                    scores += 1
                    eat_sound.play()
                    if scores == 10:
                        increase_level(2,0.07,level2_sound)
                    if scores == 20:
                        increase_level(3,0.1,level3_sound)
                    if scores >= 30:
                        game_state = "win"

            if object_falling(bombs,capybara):
                life -= 1
                if life <= 0:
                    game_state = "game_over"

            # Level 3: add superpower and crocodile
            if level == 3:
                if object_falling(superpowers,capybara):
                    life += 1

                if object_falling(crocodiles,capybara):
                        life -= 2
                        if life <= 0:
                            game_state = "game_over"

        # winning
        elif game_state == "win":
            show_win()
            if not win_sound_played:
                mixer.music.stop()
                win_sound.play()
                win_sound_played = True
        # game over
        elif game_state == "game_over":
            show_game_over()
            if not game_over_sound_played:
                mixer.music.stop()
                game_over.play()
                game_over_sound_played = True

        pygame.display.update()
        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())