import pygame
import asyncio
import random
from pygame import mixer

#sets the audio settings
pygame.mixer.pre_init(44100, -16, 2, 512)

#start
pygame.init()

#font to use in game
pixel_font = 'fonts/Pixel_game.otf'

async def main():

    game_state = "intro"
    scores = 0
    life = 5
    level = 1

    #set up the screen of the game
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("Capybara Catching Game")
    icon = pygame.image.load('images/capybara.png')
    pygame.display.set_icon(icon)

    #font
    title_font = pygame.font.Font(pixel_font, 36)
    subtitle_font = pygame.font.Font(pixel_font, 25)
    win_font = pygame.font.Font(pixel_font, 50)
    score_font = pygame.font.Font(pixel_font, 30)
    heart_font = pygame.font.Font(pixel_font, 30)
    level_font = pygame.font.Font(pixel_font, 20)
    game_over_font = pygame.font.Font(pixel_font, 50)

    # load background at the start of the game and store them to use later
    def load_bg(file_name):
        img = pygame.image.load(file_name).convert()
        return pygame.transform.scale(img, (800, 600))

    bg_images = {
        1: load_bg('images/level1_bg.png'),
        2: load_bg('images/level2_bg.png'),
        3: load_bg('images/level3_bg.png'),
    }

    # instruction text to show before game start
    title_text = title_font.render("CAPYBARA CATCHING WATERMELON GAME", True, (0, 0, 0))
    game_rule = subtitle_font.render('Instruction \n Catch 1 Watermelon -> Get 1 Score \n You have 5 life \n Touch 1 bomb -> Lose 1 life \n Get 10 score -> Go to Level 2 \n In Level 3 touch 1 superpower -> gain 1 life \nTouch 1 crocodile -> Lose 1 life" \n Press SPACE to start Level 1 ',True, (0, 0, 0))
    win_text = win_font.render("YOU WIN!", True, (255, 255, 255))
    game_over_text = game_over_font.render("GAME OVER!", True, (255, 0, 0))
    restart_text = subtitle_font.render("Press R to play again", True, (255, 255, 255))
    restart_rect = restart_text.get_rect(center=(360, 320))

    def show_intro():
        screen.blit(title_text, (120, 70))
        screen.blit(game_rule,(120,110))

    def show_win():
        screen.blit(win_text, (300, 250))

    # watermelon sprite
    watermelon_img = pygame.image.load('images/watermelon.png').convert_alpha()
    watermelon = pygame.transform.scale(watermelon_img, (60, 60))
    watermelon_gravity = 0.05
    num_watermelons = 2
    watermelon_rect = [0] * num_watermelons
    watermelon_x = []
    watermelon_y = []
    y_watermelon_velocity = [2.0] * num_watermelons

    for i in range(num_watermelons):
        watermelon_x.append(random.randint(50, 790))
        watermelon_y.append(random.randint(0, 10))

    # bomb sprite
    bomb_img = pygame.image.load('images/bomb.png').convert_alpha()
    bomb = pygame.transform.scale(bomb_img, (50, 60))
    num_bombs = 3
    bomb_rect = []
    bomb_gravity = 0.05
    bomb_x = []
    bomb_y = []
    y_bomb_velocity = []

    def Bomb():
        bomb_x.append(random.randint(50, 750))
        bomb_y.append(random.randint(0, 10))
        y_bomb_velocity.append(2.0)
        bomb_rect.append(0)

    for i in range(num_bombs):
        Bomb()

    # superpower sprite
    superpower_img = pygame.image.load('images/superpower.png').convert_alpha()
    superpower = pygame.transform.scale(superpower_img, (55, 50))
    superpower_gravity = 0.05
    num_superpowers = 1
    superpower_rect = [0] * num_superpowers
    superpower_x = []
    superpower_y = []
    y_superpower_velocity = [2.0] * num_superpowers

    for i in range(num_superpowers):
        superpower_x.append(random.randint(50, 790))
        superpower_y.append(random.randint(0, 10))

    # crocodile
    crocodile_img = pygame.image.load('images/crocodile.png').convert_alpha()
    crocodile = pygame.transform.scale(crocodile_img, (70, 70))
    crocodile_gravity = 0.05
    num_crocodiles = 2
    crocodile_rect = [0] * num_crocodiles
    crocodile_x = []
    crocodile_y = []
    y_crocodile_velocity = [2.0] * num_crocodiles

    for i in range(num_crocodiles):
        crocodile_x.append(random.randint(50, 790))
        crocodile_y.append(random.randint(0, 10))

    # score and heart icons
    score_img = pygame.image.load('images/score.png').convert_alpha()
    score_icon = pygame.transform.scale(score_img, (50, 50))
    score_icon_x = 20
    score_icon_y = 10

    heart_img = pygame.image.load('images/heart.png').convert_alpha()
    heart_icon = pygame.transform.scale(heart_img, (40, 40))
    heart_x = 25
    heart_y = 60

    def show_score():
        screen.blit(score_font.render(str(scores), True, (255, 0, 0)), (90, 20))

    def show_heart():
        screen.blit(heart_font.render(str(life), True, (255, 0, 0)), (90, 65))

    # capybara sprite
    capybara_img = pygame.image.load('images/capybara.png').convert_alpha()
    capybara_x = 250
    capybara_y = 450
    capybara = pygame.transform.scale(capybara_img, (100, 95))

    # sounds
    # for background music , use mixer.music and do loop -1 -> so it plays forever until game finished
    mixer.music.load('sound/capy_bgmusic.ogg')
    mixer.music.play(-1)  # -1 = loop forever

    #use mixer.sound for sound effects
    eat_sound = mixer.Sound('sound/eating.ogg')
    level2_sound = mixer.Sound('sound/Level2_bg.ogg')
    level3_sound = mixer.Sound('sound/Level3_bg.ogg')
    game_over = mixer.Sound('sound/game_over.ogg')
    win_sound = mixer.Sound('sound/win.ogg')
    win_sound_played = False
    game_over_sound_played = False

    def reset_game():
        #for restart option - so variable will set up again
        nonlocal game_state, scores, life, level
        nonlocal num_bombs, bomb_gravity, watermelon_gravity, capybara_x
        nonlocal win_sound_played, game_over_sound_played

        scores = 0
        life = 5
        level = 1
        capybara_x = 250
        bomb_gravity = 0.05
        watermelon_gravity = 0.05
        win_sound_played = False
        game_over_sound_played = False

        # watermelons
        for i in range(num_watermelons):
            watermelon_x[i] = random.randint(50, 750)
            watermelon_y[i] = random.randint(0, 10)
            y_watermelon_velocity[i] = 2.0

        # bombs: back to the original 3
        bomb_x.clear()
        bomb_y.clear()
        y_bomb_velocity.clear()
        bomb_rect.clear()
        num_bombs = 3
        for i in range(num_bombs):
            Bomb()

        # superpower
        for i in range(num_superpowers):
            superpower_x[i] = random.randint(50, 750)
            superpower_y[i] = random.randint(0, 10)
            y_superpower_velocity[i] = 2.0

        # crocodiles
        for i in range(num_crocodiles):
            crocodile_x[i] = random.randint(50, 750)
            crocodile_y[i] = random.randint(0, 10)
            y_crocodile_velocity[i] = 2.0

        # restart sound
        mixer.stop()
        mixer.music.stop()
        mixer.music.play(-1)

        game_state = "playing"

    clock = pygame.time.Clock()

    running = True
    while running:
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if game_state == "intro":
                    if event.key == pygame.K_SPACE:
                        game_state = "playing"
                elif game_state in ("win", "game_over"):
                    if event.key in [pygame.K_r]:
                        reset_game()

        # intro screen
        if game_state == "intro":
            screen.blit(bg_images[1], (0, 0))
            show_intro()

        # playing screen
        elif game_state == "playing":
            screen.blit(bg_images[level], (0, 0))

            capybara_rect = screen.blit(capybara, (capybara_x, capybara_y))
            screen.blit(score_icon, (score_icon_x, score_icon_y))
            screen.blit(heart_icon, (heart_x, heart_y))
            show_score()
            show_heart()

            # Capybara movement
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                capybara_x -= 7
            if keys[pygame.K_RIGHT]:
                capybara_x += 7

            # Keep capybara inside the screen
            if capybara_x <= 0:
                capybara_x = 0
            if capybara_x >= 700:
                capybara_x = 700

            # Watermelon movement
            for i in range(num_watermelons):
                watermelon_rect[i] = screen.blit(watermelon, (watermelon_x[i], watermelon_y[i]))
                y_watermelon_velocity[i] += watermelon_gravity
                watermelon_y[i] += y_watermelon_velocity[i]

                if watermelon_y[i] > 470:
                    watermelon_x[i] = random.randint(50, 750)
                    watermelon_y[i] = random.randint(0, 15)
                    y_watermelon_velocity[i] = 2

                # Capybara touches watermelon
                if capybara_rect.colliderect(watermelon_rect[i]):
                    watermelon_x[i] = random.randint(50, 750)
                    watermelon_y[i] = random.randint(0, 15)
                    y_watermelon_velocity[i] = 2

                    scores += 1
                    eat_sound.play()

                    if scores == 10:
                        level = 2
                        num_bombs += 1
                        bomb_gravity += 0.03
                        watermelon_gravity += 0.03
                        Bomb()
                        level2_sound.play()

                    if scores == 20:
                        level = 3
                        num_bombs += 2
                        bomb_gravity += 0.03
                        watermelon_gravity += 0.03
                        Bomb()
                        Bomb()
                        level3_sound.play()

                    if scores >= 30:
                        game_state = "win"

            # Bomb movement
            for i in range(num_bombs):
                bomb_rect[i] = screen.blit(bomb, (bomb_x[i], bomb_y[i]))
                y_bomb_velocity[i] += bomb_gravity
                bomb_y[i] += y_bomb_velocity[i]

                if bomb_y[i] > 470:
                    bomb_x[i] = random.randint(50, 750)
                    bomb_y[i] = random.randint(0, 15)
                    y_bomb_velocity[i] = 2

                # Capybara touches bomb
                if capybara_rect.colliderect(bomb_rect[i]):
                    bomb_x[i] = random.randint(50, 750)
                    bomb_y[i] = random.randint(0, 15)
                    y_bomb_velocity[i] = 2
                    life -= 1
                    if life <= 0:
                        game_state = "game_over"

            # Level 3: superpower and crocodile
            if level == 3:
                for i in range(num_superpowers):
                    superpower_rect[i] = screen.blit(superpower, (superpower_x[i], superpower_y[i]))
                    y_superpower_velocity[i] += superpower_gravity
                    superpower_y[i] += y_superpower_velocity[i]

                    if superpower_y[i] > 470:
                        superpower_x[i] = random.randint(50, 750)
                        superpower_y[i] = random.randint(0, 15)
                        y_superpower_velocity[i] = 2

                    if capybara_rect.colliderect(superpower_rect[i]):
                        superpower_x[i] = random.randint(50, 750)
                        superpower_y[i] = random.randint(0, 15)
                        y_superpower_velocity[i] = 2
                        life += 1

                for i in range(num_crocodiles):
                    crocodile_rect[i] = screen.blit(crocodile, (crocodile_x[i], crocodile_y[i]))
                    y_crocodile_velocity[i] += crocodile_gravity
                    crocodile_y[i] += y_crocodile_velocity[i]

                    if crocodile_y[i] > 470:
                        crocodile_x[i] = random.randint(50, 750)
                        crocodile_y[i] = random.randint(0, 15)
                        y_crocodile_velocity[i] = 2

                    if capybara_rect.colliderect(crocodile_rect[i]):
                        crocodile_x[i] = random.randint(50, 750)
                        crocodile_y[i] = random.randint(0, 15)
                        y_crocodile_velocity[i] = 2
                        life -= 2
                        # FIX: crocodile can now end the game too
                        if life <= 0:
                            game_state = "game_over"

            level_text = level_font.render("Level: " + str(level), True, (0, 255, 0))
            screen.blit(level_text, (680, 10))

        # winning
        elif game_state == "win":
            screen.blit(bg_images[3], (0, 0))
            show_win()
            screen.blit(restart_text, restart_rect)
            if not win_sound_played:
                mixer.music.stop()
                win_sound.play()
                win_sound_played = True

        # game over
        elif game_state == "game_over":
            screen.blit(bg_images[3], (0, 0))
            screen.blit(game_over_text, (260, 250))
            screen.blit(restart_text, restart_rect)
            if not game_over_sound_played:
                mixer.music.stop()
                game_over.play()
                game_over_sound_played = True

        pygame.display.update()
        await asyncio.sleep(0)   # REQUIRED for the browser: runs once per frame, on every screen

    pygame.quit()

asyncio.run(main())